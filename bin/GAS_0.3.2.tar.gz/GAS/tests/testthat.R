library("testthat")

test_check("GAS")
