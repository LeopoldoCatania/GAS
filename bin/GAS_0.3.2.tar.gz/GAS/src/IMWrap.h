#ifndef IMWRAP_H
#define IMWRAP_H

arma::mat IM_univ(arma::vec vTheta,std::string Dist);
#endif
