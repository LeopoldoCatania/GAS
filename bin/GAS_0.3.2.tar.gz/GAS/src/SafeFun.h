#ifndef SAFEFUN_H
#define SAFEFUN_H

double lgammafn_safe(double dX);
arma::mat chol_safe(arma::mat mX);

#endif
